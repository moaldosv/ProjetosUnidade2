var searchData=
[
  ['writeoff',['writeOFF',['../class_sculptor.html#a4faae5ab2d72f2f682005f468e7e8a92',1,'Sculptor']]],
  ['writevect',['writeVECT',['../class_sculptor.html#a200442de17ed45b7a1ece728145a2ddf',1,'Sculptor']]]
];
