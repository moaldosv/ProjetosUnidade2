var searchData=
[
  ['cutbox',['cutBox',['../class_sculptor.html#aa84a1b12b09e9e103fc8d78f8d1bc00f',1,'Sculptor']]],
  ['cutellipsoid',['cutEllipsoid',['../class_sculptor.html#a18d2922c111c4c13653ee07d878151ad',1,'Sculptor']]],
  ['cutsphere',['cutSphere',['../class_sculptor.html#a67ab8c0ba5116adb8af1d01ad373ac15',1,'Sculptor']]],
  ['cutvoxel',['cutVoxel',['../class_sculptor.html#ad9d714a35fc8ae16d06eb5df37c3493c',1,'Sculptor']]]
];
