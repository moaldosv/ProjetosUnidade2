var searchData=
[
  ['sculptor',['Sculptor',['../class_sculptor.html',1,'Sculptor'],['../class_sculptor.html#a5e75695b8f097cdf0fa90bd721d1aa61',1,'Sculptor::Sculptor()']]],
  ['setcolor',['setColor',['../class_sculptor.html#af1d69da01379874b0dfd6454787cb562',1,'Sculptor']]]
];
